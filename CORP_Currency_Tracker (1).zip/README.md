# CORP Currency Tracker

Open `index.html` in a browser.

Included:
- Navy-blue + wood-accent visual design
- Login and account creation
- $100,000 starting balance
- Required Discord gate with the supplied invite
- Dashboard, currency tracker, spending ledger and deposits
- Listed jobs plus automatic in-game-bank-style payments
- Create-a-job page with a rule-based payment engine
- Special jobs: Police, Firefighter, Paramedic
- Owner panel (prototype: use username `owner` when creating the account)
- LocalStorage persistence

Important:
This is a standalone front-end prototype. It cannot securely authenticate users, make real bank transfers, enforce purchases inside Roblox, or directly connect to American Plains Mudding unless the Roblox experience exposes a server/API integration.

For a production Roblox connection, implement the authoritative balance/payment logic in Roblox server scripts and a secure backend. Never trust browser-side balances for real currency.
